<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>RaspberryPints</title>
<link href="styles/layout.css" rel="stylesheet" type="text/css" />
<link href="styles/login.css" rel="stylesheet" type="text/css" />
<!-- Theme Start -->
<link href="styles.css" rel="stylesheet" type="text/css" />
<!-- Theme End -->

</head>
<body>
	<div id="logincontainer">
		<div id="loginbox">
			<div id="loginheader">
				<a href="../" style="text-decoration:none;"><h1><font color="#00CCFF">RaspberryPints Login</h1></font></a>
			</div>
			<div id="innerlogin">
				<form name="??" action="" method="POST">

					<p><input type="button" value="Forgot Password?" title="Forgot password?" class="btnalt" onClick="location. href='includes/email_to.php'" /><br /><br />
					<input type="button" value="Forgot Login Name?" title="Forgot Login Name?" class="btnalt" onClick="location. href='includes/email_tou.php'" />
				</form><br />
<a href="index.php" style="text-decoration:none;"><font color="grey">Go Back To Login</font></a> 
			</div>
		</div>
	</div>
</body>
</html>
