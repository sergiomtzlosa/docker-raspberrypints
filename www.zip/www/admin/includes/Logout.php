<?php
session_start();
session_destroy();
?>
<html>
<meta http-equiv="REFRESH" content="0;url=../index.phpl"></HEAD>
<body bgcolor="black">
</body>
</html>